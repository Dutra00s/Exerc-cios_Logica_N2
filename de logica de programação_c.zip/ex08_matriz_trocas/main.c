#include <stdio.h>

void imprimir(int A[10][10]) {
    int i, j;
    for (i = 0; i < 10; i++) {
        for (j = 0; j < 10; j++)
            printf("%3d ", A[i][j]);
        printf("\n");
    }
}

/* O enunciado conta de 1; em C os indices comecam em 0 */
void trocar_matriz(int A[10][10]) {
    int i, j, aux;

    /* linha 2 com linha 8 */
    for (j = 0; j < 10; j++) {
        aux = A[1][j];
        A[1][j] = A[7][j];
        A[7][j] = aux;
    }

    /* coluna 4 com coluna 10 */
    for (i = 0; i < 10; i++) {
        aux = A[i][3];
        A[i][3] = A[i][9];
        A[i][9] = aux;
    }

    /* diagonal principal com secundaria */
    for (i = 0; i < 10; i++) {
        aux = A[i][i];
        A[i][i] = A[i][9 - i];
        A[i][9 - i] = aux;
    }

    /* linha 5 com coluna 10 */
    for (j = 0; j < 10; j++) {
        aux = A[4][j];
        A[4][j] = A[j][9];
        A[j][9] = aux;
    }
}

int main(void) {
    int A[10][10], i, j;

    for (i = 0; i < 10; i++)
        for (j = 0; j < 10; j++)
            A[i][j] = i * 10 + j;

    printf("Matriz original:\n");
    imprimir(A);

    trocar_matriz(A);

    printf("\nMatriz alterada:\n");
    imprimir(A);
    return 0;
}
