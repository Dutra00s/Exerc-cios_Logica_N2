#include <stdio.h>

#define PI 3.1414592 /* valor dado no enunciado */

/* Volume do cilindro = PI * raio^2 * altura */
double volume_cilindro(double altura, double raio) {
    return PI * raio * raio * altura;
}

int main(void) {
    double altura, raio;

    printf("Altura do cilindro: ");
    scanf("%lf", &altura);
    printf("Raio do cilindro: ");
    scanf("%lf", &raio);

    printf("Volume: %.2f\n", volume_cilindro(altura, raio));
    return 0;
}
