#include <stdio.h>

/* Converte Fahrenheit para Celsius */
double fahrenheit_para_celsius(double f) {
    return (f - 32.0) * (5.0 / 9.0);
}

int main(void) {
    double f;

    printf("Temperatura em Fahrenheit: ");
    scanf("%lf", &f);

    printf("%.2f F = %.2f C\n", f, fahrenheit_para_celsius(f));
    return 0;
}
