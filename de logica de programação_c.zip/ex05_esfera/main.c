#include <stdio.h>

#define PI 3.1414592 /* mesmo valor do exercicio 4 */

/* Volume da esfera = 4/3 * PI * r^3
   Usa 4.0/3.0 porque 4/3 em C e divisao inteira (daria 1) */
double volume_esfera(double raio) {
    return (4.0 / 3.0) * PI * raio * raio * raio;
}

int main(void) {
    double r;

    printf("Raio da esfera: ");
    scanf("%lf", &r);

    printf("Volume: %.2f\n", volume_esfera(r));
    return 0;
}
