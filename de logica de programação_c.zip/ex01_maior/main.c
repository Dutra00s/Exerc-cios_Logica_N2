#include <stdio.h>

/* Retorna o maior entre dois numeros */
double maior(double a, double b) {
    if (a > b)
        return a;
    return b;
}

int main(void) {
    double x, y;

    printf("Digite o primeiro numero: ");
    scanf("%lf", &x);
    printf("Digite o segundo numero: ");
    scanf("%lf", &y);

    printf("O maior e: %.2f\n", maior(x, y));
    return 0;
}
