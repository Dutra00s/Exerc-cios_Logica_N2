#include <stdio.h>
#include <time.h>

int dias_do_mes(int mes, int ano) {
    int dias[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int bissexto = (ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0);

    if (mes == 2 && bissexto)
        return 29;
    return dias[mes - 1];
}

void calcular_idade(int dia, int mes, int ano) {
    time_t agora = time(NULL);
    struct tm *hoje = localtime(&agora);
    int d = hoje->tm_mday;
    int m = hoje->tm_mon + 1;
    int a = hoje->tm_year + 1900;

    int anos = a - ano;
    int meses = m - mes;
    int dias = d - dia;

    if (dias < 0) {
        int mes_anterior = (m == 1) ? 12 : m - 1;
        int ano_anterior = (m == 1) ? a - 1 : a;
        meses--;
        dias += dias_do_mes(mes_anterior, ano_anterior);
    }
    if (meses < 0) {
        anos--;
        meses += 12;
    }

    printf("Idade: %d anos, %d meses e %d dias\n", anos, meses, dias);
}

int main(void) {
    int dia, mes, ano;

    printf("Data de nascimento (dd mm aaaa): ");
    scanf("%d %d %d", &dia, &mes, &ano);

    calcular_idade(dia, mes, ano);
    return 0;
}
