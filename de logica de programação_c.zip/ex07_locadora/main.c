#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 500

/* A = filmes retirados por cliente; gratis = locacoes gratis de cada um */
void locacoes_gratis(int A[N], int gratis[N]) {
    int i;
    for (i = 0; i < N; i++)
        gratis[i] = A[i] / 15; /* divisao inteira: a cada 15 filmes, 1 gratis */
}

int main(void) {
    int A[N], gratis[N], i;

    /* dados de exemplo (aleatorios de 0 a 99) */
    srand((unsigned) time(NULL));
    for (i = 0; i < N; i++)
        A[i] = rand() % 100;

    locacoes_gratis(A, gratis);

    printf("Cliente | Filmes | Gratis\n");
    for (i = 0; i < 10; i++) /* mostra so os 10 primeiros */
        printf("%7d | %6d | %6d\n", i + 1, A[i], gratis[i]);

    return 0;
}
