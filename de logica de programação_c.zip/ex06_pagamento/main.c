#include <stdio.h>
#include <math.h>

/* Imprime as opcoes, le a escolha e retorna a opcao */
char escolher_opcao(double total) {
    char opcao;

    printf("\nOpcoes de pagamento:\n");
    printf("a) A vista com 10%% de desconto\n");
    printf("b) Em 2 vezes (preco da etiqueta)\n");
    if (total > 100)
        printf("c) De 3 a 10 vezes com 3%% de juros ao mes\n");

    while (1) {
        printf("Escolha a opcao: ");
        scanf(" %c", &opcao);
        if (opcao == 'a' || opcao == 'b' || (opcao == 'c' && total > 100))
            return opcao;
        printf("Opcao invalida.\n");
    }
}

void pagamento_a_vista(double total) {
    printf("A vista: R$ %.2f\n", total * 0.90);
}

void pagamento_duas_vezes(double total) {
    printf("2 parcelas de R$ %.2f\n", total / 2);
}

void pagamento_parcelado(double total) {
    int n;
    double i = 0.03, parcela;

    do {
        printf("Numero de parcelas (3 a 10): ");
        scanf("%d", &n);
    } while (n < 3 || n > 10);

    /* prestacao com juros compostos (tabela Price) */
    parcela = total * i / (1 - pow(1 + i, -n));
    printf("%d parcelas de R$ %.2f (total R$ %.2f)\n", n, parcela, parcela * n);
}

int main(void) {
    double total;
    char opcao;

    printf("Total gasto pelo cliente: R$ ");
    scanf("%lf", &total);

    opcao = escolher_opcao(total);

    if (opcao == 'a')
        pagamento_a_vista(total);
    else if (opcao == 'b')
        pagamento_duas_vezes(total);
    else
        pagamento_parcelado(total);

    return 0;
}
