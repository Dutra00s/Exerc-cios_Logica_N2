#include <stdio.h>

/* Soma cada coluna (linhas 0 a 59) e guarda na 61a linha (indice 60) */
void somar_colunas(int M[61][10]) {
    int i, j, soma;

    for (j = 0; j < 10; j++) {
        soma = 0;
        for (i = 0; i < 60; i++)
            soma += M[i][j];
        M[60][j] = soma;
    }
}

int main(void) {
    int M[61][10], i, j;

    /* dados de exemplo: cada elemento = numero da coluna + 1 */
    for (i = 0; i < 60; i++)
        for (j = 0; j < 10; j++)
            M[i][j] = j + 1;

    somar_colunas(M);

    printf("Somas das colunas (61a linha):\n");
    for (j = 0; j < 10; j++)
        printf("Coluna %d: %d\n", j + 1, M[60][j]);

    return 0;
}
